﻿

function demoscope() {

    //var i = 100;
   
   // i = 'd';


    for (var  i = 0; i < 3; i++) { // let
        console.log(i);
    }

    console.log(i);

}

demoscope();