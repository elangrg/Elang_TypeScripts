﻿function demof()
{

console.log('this is refered file');
}

