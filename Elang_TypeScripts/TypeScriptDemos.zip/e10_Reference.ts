﻿// Including references to a definition file:
//<reference path="jquery.ts" />
demof();
