﻿function demo(message) {
    console.log(message);
}

var message = 'hello, greeting!!';
demo(message)


