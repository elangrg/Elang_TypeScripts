// Template Strings (strings that use backticks)
// String Interpolation with Template Strings
var EmpName = 'Ganesh';
var greeting = "Hi " + EmpName + ", how are you?";
// Multiline Strings with Template Strings
var multiline = "This is an example\n\n\nof a multiline string";
var tmp = "\n\n\n";
console.log(EmpName);
console.log(greeting);
console.log(multiline);
//# sourceMappingURL=e9_StringInterpo.js.map