"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EmployeeUtility = /** @class */ (function () {
    function EmployeeUtility() {
    }
    EmployeeUtility.prototype.GenerateEmpID = function () {
        return 1000;
    };
    return EmployeeUtility;
}());
exports.EmployeeUtility = EmployeeUtility;
//# sourceMappingURL=e11_ExternalModule.js.map