function demo(message) {
    console.log(message);
}
var message = 'hello, greeting!!';
demo(message);
//# sourceMappingURL=e1_TSvsJS.js.map