function demoscope() {
    var i = 100;
    //i = 'd';
    for (var i_1 = 0; i_1 < 3; i_1++) { // let
        console.log(i_1);
    }
    console.log(i);
}
demoscope();
//# sourceMappingURL=e2_ScopeDemo.js.map