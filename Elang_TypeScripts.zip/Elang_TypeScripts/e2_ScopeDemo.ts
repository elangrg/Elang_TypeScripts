﻿

function demoscope() {

    let i = 100;
   
    //i = 'd';


    for (let  i = 0; i < 3; i++) { // let
        console.log(i);
    }

    console.log(i);

}

demoscope();