function demof() {
    console.log('this is refered file');
}
//# sourceMappingURL=jquery.js.map