// Including references to a definition file:
//<reference path="jquery.ts" />
demof();
//# sourceMappingURL=e10_Reference.js.map